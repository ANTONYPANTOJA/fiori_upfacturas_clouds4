sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "ns/asa/zappuploadinvoices/controller/BaseController",
],
function (Controller,BaseController) {
    "use strict";

    return BaseController.extend("ns.asa.zappuploadinvoices.controller.NotFound", {
        onInit: function () {

        }
    });
});