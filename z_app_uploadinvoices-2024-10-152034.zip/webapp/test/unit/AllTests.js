sap.ui.define([
	"nsasa/z_app_uploadinvoices/test/unit/controller/App.controller"
], function () {
	"use strict";
});
