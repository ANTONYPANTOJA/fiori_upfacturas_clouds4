/* global QUnit */

sap.ui.require(["ns/asa/zappuploadinvoices/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
