sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
function (Controller) {
    "use strict";

    return Controller.extend("ns.asa.zappuploadinvoices.controller.App", {
        onInit: function () {

        }
    });
});
